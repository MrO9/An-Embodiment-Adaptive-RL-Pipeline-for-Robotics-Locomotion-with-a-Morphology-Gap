# GitHub Pages setup
1. Put everything in this folder at the root of a repo (or in /docs).
2. Add your compiled paper as `paper.pdf` next to index.html (the Paper button links to it).
3. Repo Settings > Pages > deploy from the branch/folder.
